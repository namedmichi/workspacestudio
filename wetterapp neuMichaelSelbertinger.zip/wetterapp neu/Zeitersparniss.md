# Unterstützung durch github Copilot(ChatGPT) bei:

-   Schreiben von Repetitiven Code
-   Autovervollständigung von vorhersehbaren Code

Zeitersparnis: 50-75%
